import{aW as t}from"../chunks/entry.DjYp6XJk.js";export{t as start};
